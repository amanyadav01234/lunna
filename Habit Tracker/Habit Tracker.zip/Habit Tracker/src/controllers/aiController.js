// @desc    Suggest habits based on goal
// @route   POST /suggest-habits
// @access  Public
const suggestHabits = async (req, res) => {
    const { goal } = req.body;

    if (!goal) {
        return res.status(400).json({ message: 'Please provide a goal' });
    }

    // Mocked AI response
    // In a real app, this would call OpenAI or Gemini API
    const suggestions = [
        `Read about ${goal} for 15 minutes`,
        `Practice ${goal} every morning`,
        `Join a community for ${goal}`,
    ];

    res.status(200).json({ suggestions });
};

module.exports = {
    suggestHabits,
};
