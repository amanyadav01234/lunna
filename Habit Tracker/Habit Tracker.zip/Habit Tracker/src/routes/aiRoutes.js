const express = require('express');
const router = express.Router();
const { suggestHabits } = require('../controllers/aiController');

router.post('/', suggestHabits);

module.exports = router;
