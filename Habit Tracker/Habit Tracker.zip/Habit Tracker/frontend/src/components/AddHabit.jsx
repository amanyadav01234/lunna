import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Sparkles, X } from 'lucide-react';
import axios from 'axios';

const AddHabit = ({ onAdd }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [name, setName] = useState('');
    const [goal, setGoal] = useState('');
    const [suggestions, setSuggestions] = useState([]);
    const [loadingAI, setLoadingAI] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!name.trim()) return;
        try {
            await axios.post('/habits', { name });
            setName('');
            setIsOpen(false);
            onAdd();
        } catch (error) {
            console.error('Error adding habit:', error);
        }
    };

    const getSuggestions = async () => {
        if (!goal.trim()) return;
        setLoadingAI(true);
        try {
            const res = await axios.post('/suggest-habits', { goal });
            setSuggestions(res.data.suggestions);
        } catch (error) {
            console.error('Error getting suggestions:', error);
        } finally {
            setLoadingAI(false);
        }
    };

    return (
        <>
            <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsOpen(true)}
                className="fixed bottom-8 right-8 w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(99,102,241,0.5)] z-50"
            >
                <Plus className="w-8 h-8 text-white" />
            </motion.button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
                    >
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            exit={{ scale: 0.9, opacity: 0 }}
                            className="glass-panel w-full max-w-md p-6 relative"
                        >
                            <button
                                onClick={() => setIsOpen(false)}
                                className="absolute top-4 right-4 text-white/50 hover:text-white"
                            >
                                <X className="w-6 h-6" />
                            </button>

                            <h2 className="text-2xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
                                New Habit
                            </h2>

                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <label className="block text-sm text-white/60 mb-2">Habit Name</label>
                                    <input
                                        type="text"
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                        className="input-field"
                                        placeholder="e.g., Drink Water"
                                        autoFocus
                                    />
                                </div>

                                <div className="pt-4 border-t border-white/10">
                                    <label className="block text-sm text-primary mb-2 flex items-center gap-2">
                                        <Sparkles className="w-4 h-4" />
                                        AI Assistant
                                    </label>
                                    <div className="flex gap-2">
                                        <input
                                            type="text"
                                            value={goal}
                                            onChange={(e) => setGoal(e.target.value)}
                                            className="input-field text-sm"
                                            placeholder="Describe your goal..."
                                        />
                                        <button
                                            type="button"
                                            onClick={getSuggestions}
                                            disabled={loadingAI}
                                            className="px-4 py-2 bg-white/10 rounded-xl hover:bg-white/20 transition-colors disabled:opacity-50"
                                        >
                                            {loadingAI ? '...' : 'Ask'}
                                        </button>
                                    </div>
                                </div>

                                {suggestions.length > 0 && (
                                    <div className="flex flex-wrap gap-2 mt-2">
                                        {suggestions.map((s, i) => (
                                            <button
                                                key={i}
                                                type="button"
                                                onClick={() => setName(s)}
                                                className="text-xs px-3 py-1 bg-primary/20 text-primary rounded-full hover:bg-primary/30 transition-colors"
                                            >
                                                {s}
                                            </button>
                                        ))}
                                    </div>
                                )}

                                <button type="submit" className="btn-primary w-full mt-6">
                                    Create Habit
                                </button>
                            </form>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default AddHabit;
