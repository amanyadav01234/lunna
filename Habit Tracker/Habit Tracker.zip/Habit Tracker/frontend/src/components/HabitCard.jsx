import React from 'react';
import { motion } from 'framer-motion';
import { Check, Flame, Trash2 } from 'lucide-react';
import axios from 'axios';

const HabitCard = ({ habit, onUpdate, onDelete }) => {
    const handleComplete = async () => {
        try {
            await axios.patch(`/habits/${habit._id}/complete`);
            onUpdate();
        } catch (error) {
            console.error('Error marking complete:', error);
        }
    };

    const handleDelete = async () => {
        try {
            await axios.delete(`/habits/${habit._id}`);
            onDelete();
        } catch (error) {
            console.error('Error deleting habit:', error);
        }
    };

    const isCompletedToday = () => {
        if (!habit.lastCompleted) return false;
        const today = new Date().setHours(0, 0, 0, 0);
        const last = new Date(habit.lastCompleted).setHours(0, 0, 0, 0);
        return today === last;
    };

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="glass-panel p-6 flex items-center justify-between group hover:bg-white/10 transition-colors"
        >
            <div className="flex items-center gap-4">
                <button
                    onClick={handleComplete}
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${isCompletedToday()
                            ? 'bg-green-500 shadow-[0_0_20px_rgba(34,197,94,0.5)]'
                            : 'bg-white/10 hover:bg-white/20'
                        }`}
                >
                    <Check className={`w-6 h-6 ${isCompletedToday() ? 'text-white' : 'text-white/30'}`} />
                </button>
                <div>
                    <h3 className="text-xl font-semibold">{habit.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-white/50 mt-1">
                        <Flame className={`w-4 h-4 ${habit.streak > 0 ? 'text-orange-500' : ''}`} />
                        <span>{habit.streak} Day Streak</span>
                    </div>
                </div>
            </div>

            <button
                onClick={handleDelete}
                className="p-2 text-white/20 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
            >
                <Trash2 className="w-5 h-5" />
            </button>
        </motion.div>
    );
};

export default HabitCard;
