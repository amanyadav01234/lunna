import React, { useEffect, useState } from 'react';
import axios from 'axios';
import HabitCard from './components/HabitCard';
import AddHabit from './components/AddHabit';

function App() {
  const [habits, setHabits] = useState([]);

  const fetchHabits = async () => {
    try {
      const res = await axios.get('/habits');
      setHabits(res.data);
    } catch (error) {
      console.error('Error fetching habits:', error);
    }
  };

  useEffect(() => {
    fetchHabits();
  }, []);

  return (
    <div className="min-h-screen bg-dark text-white selection:bg-primary/30">
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/20 rounded-full blur-[120px]" />
      </div>

      <div className="relative max-w-2xl mx-auto px-6 py-12">
        <header className="mb-12">
          <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
            Habit Tracker
          </h1>
          <p className="text-white/50 mt-2">Build better habits, one day at a time.</p>
        </header>

        <div className="space-y-4">
          {habits.map((habit) => (
            <HabitCard
              key={habit._id}
              habit={habit}
              onUpdate={fetchHabits}
              onDelete={fetchHabits}
            />
          ))}

          {habits.length === 0 && (
            <div className="text-center py-20 text-white/30">
              No habits yet. Start by adding one!
            </div>
          )}
        </div>

        <AddHabit onAdd={fetchHabits} />
      </div>
    </div>
  );
}

export default App;
